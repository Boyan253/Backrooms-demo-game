---
title: open-graph
---

[Open a graph file](../vs-open-graph-edit.md) in the Graph window.