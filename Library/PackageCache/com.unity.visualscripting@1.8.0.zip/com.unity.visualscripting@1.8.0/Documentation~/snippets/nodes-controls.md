---
title: nodes-controls
---

node has the following controls: