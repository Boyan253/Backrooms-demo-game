---
title: with-graph-open-ff
---
With a Script Graph [open in the Graph window](../vs-open-graph-edit.md), right-click on an empty space in the Graph Editor to open the fuzzy finder. 
