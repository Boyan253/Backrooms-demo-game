namespace Unity.VisualScripting
{
    public static class InspectorUtility { }
}
