using System;

namespace Unity.VisualScripting
{
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class InitializeAfterPluginsAttribute : Attribute { }
}
