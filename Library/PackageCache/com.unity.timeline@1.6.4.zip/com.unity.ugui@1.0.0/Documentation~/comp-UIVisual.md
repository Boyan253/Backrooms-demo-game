# Visual Components

The [visual components](UIVisualComponents.md) allow for ease of creation and GUI specific functionality.

* [Text](script-Text.md)
* [Image](script-Image.md)
* [Raw Image](script-RawImage.md)
* [Mask](script-Mask.md)
